package SelleniumClass9;

public class DataProvider {

}
