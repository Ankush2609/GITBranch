package com.testng.db;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SeleniumClass9 {

	@Test()
	public void Samplemethod()				
	{		
	    System.out.println("This method to test fail");					
	    Assert.assertTrue(false);			
	}	
}
