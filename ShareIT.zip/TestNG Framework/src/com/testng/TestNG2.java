package com.testng;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNG2 
{

/*	@Test(invocationCount=3,skipFailedInvocations=true)
	public void TestNG2m1() throws InterruptedException
	{
		System.out.println("TestNG2: M1");
		Thread.sleep(2000);
	}
	
	@Test(dependsOnMethods= {"TestNG2m1"},alwaysRun = true)
	public void TestNG2m2() throws InterruptedException
	{
		System.out.println("TestNG2: M2");
		Thread.sleep(2000);
	}
	
	@Test
	@Parameters({"name","age"})
	public void TestNG2m3(String name, String age) throws InterruptedException
	{
		System.out.println("TestNG2: Name: "+name+"Age: "+age);
		Thread.sleep(2000);
	}
	
	@Test
	public void TestNG2m4() throws InterruptedException
	{
		System.out.println("TestNG2: M4");
		Thread.sleep(2000);
	}
	
	@Test(dataProvider ="dp1", dataProviderClass=com.testng.dp.DP.class)
	public void TestNG2m5(int no1, int no2) throws InterruptedException
	{
		System.out.println("TestNG2: M4");
		//System.out.println(no+"is Even : "+(no%2==0?true:false));
		System.out.println("No. 1: "+no1+ "No. 2: "+no2);
		Thread.sleep(2000);
	}*/

}
